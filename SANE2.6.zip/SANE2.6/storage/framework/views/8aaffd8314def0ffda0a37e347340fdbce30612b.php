

<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" type="text/css"> -->
    <title>Importar</title>
</head>
<body>
    <header>
    <nav>
        Importar archivo (CSV)
    </nav>
    </header>

    <!-- <form action="<?php echo e(route('importar.post')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="document_xls" required>
    <button type="submit" class="btn success animated-button"><span>Convertir a CSV</span></button>
</form> -->

    <form action="<?php echo e(route('importar2.post')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="document_csv" required>
    <button type="submit" class="btn success animated-button"><span>Importar</span></button>
</form>

<a href="/files">Ver Archivos</a>
    
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\66762\Desktop\SANE2.2\resources\views/csv.blade.php ENDPATH**/ ?>