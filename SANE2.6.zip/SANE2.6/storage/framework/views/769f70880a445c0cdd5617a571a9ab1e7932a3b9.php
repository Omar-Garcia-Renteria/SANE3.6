<!DOCTYPE html>
<html>
<head>
    <title>User Data</title>
</head>
<body>
    <h1>Datos de los usuarios</h1>
    <table>
        <thead>
            <!-- <tr>
                <th>ID</th>
                <th>Name</th>
                <th>CURP</th>
                <th>Email</th>
            </tr> -->
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->nombre); ?></td>
                <td><?php echo e($user->prim_apell); ?></td>
                <td><?php echo e($user->seg_apell); ?></td>
                <td><?php echo e($user->curp); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="container">
        <br>
        <div class="row">
            <div class="clod-md-4"></div>
            <div class="clod-md-6">
            <!-- <div class="row">

                <form method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                <div class="clo-md-6">
                    <input type="file" name="documento">
                </div>
                <div class="clo-md-6">
                    <button class="btn btn-primary" type="submit">Importar</button>
                </div>
                </form>
            </div> -->
            </div>
            <!-- <head>
    <title>Buscar por CURP</title>
</head>
<body>
    <form action="<?php echo e(route('search')); ?>" method="GET">
        <label for="curp">CURP:</label>
        <input type="text" id="curp" name="curp" required>
        <button type="submit">Buscar</button>
        <div class="col-md-2">
                <button class="btn btn-success">Exportar</button>
            </div>
    </form>

    


</body> -->

<style>
        td {
            font-weight: bold; 
            font-size: 20px; 
        }
    </style>


</html>
<?php /**PATH C:\Users\66762\Desktop\SANE2.0\resources\views/curps.blade.php ENDPATH**/ ?>