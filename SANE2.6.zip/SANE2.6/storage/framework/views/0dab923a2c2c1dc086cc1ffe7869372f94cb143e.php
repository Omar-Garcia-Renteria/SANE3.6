<!DOCTYPE html>




<?php $__env->startSection('contenido'); ?>
    <div class="container">
        <p>PUMA</p>
    </div>

    <div class="productos">
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://dpjye2wk9gi5z.cloudfront.net/wcsstore/ExtendedSitesCatalogAssetStore/images/catalog/zoom/1028561-0100V1.jpg" alt="" width="80px">
        <p><a href="/zap">Tenis Puma Caven 2.0</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://resources.claroshop.com/medios-plazavip/mkt/64b1aabac119f_37476522_f396c4dd-1a51-48fc-b0d5-30d54f7283d8png.jpg?scale=500&qlty=75" alt="" width="80px">
        <p><a href="/zap">Tenis Puma Rebound Joy</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3ALnc0Goj6BtGdRqF1wh4HQ8zeJA2c2kvJWK7v9EJFw&s" alt="" width="80px">
        <p><a href="/zap">Tenis Puma Ferrari Low Racer</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://martimx.vtexassets.com/arquivos/ids/1184798-800-800?v=638252185973130000&width=800&height=800&aspect=true" alt="" width="80px">
        <p><a href="/zap">R22</a></p>
    </div>
</div>

<div class="productos">
    <div class="producto"style="display: inline-block; text-align: center;">
        <img src="https://dpjye2wk9gi5z.cloudfront.net/wcsstore/ExtendedSitesCatalogAssetStore/images/catalog/zoom/1027836-0109V1.jpg" alt="" width="80px">
        <p><a href="/zap">RS-X Gen</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://www.staplepigeon.com/cdn/shop/products/STPL_0515.jpg?v=1685561878" alt="" width="80px">
        <p><a href="/zap">STAPLE Slipstream</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://dpjye2wk9gi5z.cloudfront.net/wcsstore/ExtendedSitesCatalogAssetStore/images/catalog/zoom/1028554-0099V1.jpg" alt="" width="80px">
        <p><a href="/zap">Triniry BMW Motorsport</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://i5.walmartimages.com.mx/mg/gm/3pp/asr/43a56722-566d-48d6-8d33-d241877650f7.958ba04d51fc7381bd29e83dc3b24a4f.jpeg?odnHeight=612&odnWidth=612&odnBg=FFFFFF" alt="" width="80px">
        <p><a href="/zap">Retaliate 2 Camo</a></p>
    </div>
</div>



<style>
    /* Estilos para el contenedor de productos */
.productos {
    text-align: center; /* Centra los productos horizontalmente */
    color: #082D0E;
}

/* Estilos para cada contenedor de producto */
.producto {
    display: inline-block; /* Muestra los productos en línea */
    margin: 10px; /* Añade un margen alrededor de cada producto */
    padding: 10px; /* Añade espacio interno alrededor de cada producto */
    border: 1px solid #ccc; /* Agrega un borde alrededor de cada producto */
    width: 150px; /* Define el ancho de cada producto */
    color: #082D0E;
}

/* Estilos para la imagen del producto */
.producto img {
    width: 100px; /* Define el ancho de la imagen del producto */
}

/* Estilos para el texto del producto */
.producto p {
    margin-top: 5px; /* Añade espacio superior al texto */
    font-size: 14px; /* Define el tamaño de fuente del texto */
}

</style>

<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\66762\Desktop\CRUZ\MyBlog2\resources\views/puma.blade.php ENDPATH**/ ?>