

<?php $__env->startSection('contenido'); ?>
<div class="container w-25 border p-4 mt-4">
<form action="<?php echo e(route('agenda')); ?>" method = "POST">
  <?php echo csrf_field(); ?>

  <?php if(session('success')): ?>
    <h6 class="alert alert-success"><?php echo e(session('success')); ?></h6>
  <?php endif; ?>

  <?php $__errorArgs = ['cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <h6 class="alert alert-danger"><?php echo e($message); ?></h6>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="mb-3">
    <label for="cliente" class="form-label">Cliente</label>
    <input type="text" name ="cliente" class="form-control">
    </div>
        
  <button type="submit" class="btn btn-primary">Nuevo cliente</button>
</form>

<div>
  <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="row py-1">
    <div class="col-md-5 d-flex justify-content-end">
      <a href="<?php echo e(route('citas-show', ['id' => $cita->id])); ?>"><?php echo e($cita->cliente); ?></a>
    </div>
    <div class="col-md-5 d-flex justify-content-end">
      <form action="<?php echo e(route('citas-destroy', [$cita->id])); ?>" method="POST">
          <?php echo method_field('DELETE'); ?>
          <?php echo csrf_field(); ?>
          <button class="btn btn-danger btm-sm">Eliminar</button>
      </form>  
    </div>
  </div>  
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

    
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\MyBlog\resources\views/contacto/index.blade.php ENDPATH**/ ?>