
<!DOCTYPE html>




<?php $__env->startSection('contenido'); ?>
    <div class="container">
        <p>PLAYERAS</p>
    </div>

    <div class="productos">
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://www.sopitas.com/wp-content/uploads/2021/12/jersey-bayern-munich-2021-1.jpg" alt="" width="80px">
        <p><a href="/zap">BAYERN MUNICH 21-22</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://www.sopitas.com/wp-content/uploads/2021/12/jersey-napoli-2021.jpg" alt="" width="80px">
        <p><a href="/zap">NAPOLI Maradona</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://depor.com/resizer/bOOzdDrJu292k66qT411nnUTnZM=/980x0/smart/filters:format(jpeg):quality(90)/cloudfront-us-east-1.images.arcpublishing.com/elcomercio/FT4YUZLBR5CCBNXBHSK6DPTVEU.jpg" alt="" width="80px">
        <p><a href="/zap">ALEMANIA 2022</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://www.sopitas.com/wp-content/uploads/2021/12/jersey-inter-milan-2021.jpg" alt="" width="80px">
        <p><a href="/zap">INTER DE MILAN</a></p>
    </div>
</div>

<div class="productos">
    <div class="producto"style="display: inline-block; text-align: center;">
        <img src="https://bolavip.com/export/sites/bolavip/img/2021/12/29/47_chelsea.jpg_1543673193.jpg" alt="" width="80px">
        <p><a href="/zap">CHELSEA</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://www.sopitas.com/wp-content/uploads/2022/12/jersey-brasil-2022.jpg?w=800" alt="" width="80px">
        <p><a href="/zap">BRACIL 2022</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://a2.espncdn.com/combiner/i?img=%2Fphoto%2F2022%2F0805%2Fr1044606_1000x1000_1%2D1.jpg&w=570&h=570&format=jpg" alt="" width="80px">
        <p><a href="/zap">AJAX</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://bolavip.com/export/sites/bolavip/img/2021/12/29/3_borussia_dortmund.jpg_1543673193.jpg" alt="" width="80px">
        <p><a href="/zap">BORUSSIA DORTMUND</a></p>
    </div>
</div>



<style>
    /* Estilos para el contenedor de productos */
.productos {
    text-align: center; /* Centra los productos horizontalmente */
    color: #082D0E;
}

/* Estilos para cada contenedor de producto */
.producto {
    display: inline-block; /* Muestra los productos en línea */
    margin: 10px; /* Añade un margen alrededor de cada producto */
    padding: 10px; /* Añade espacio interno alrededor de cada producto */
    border: 1px solid #ccc; /* Agrega un borde alrededor de cada producto */
    width: 150px; /* Define el ancho de cada producto */
    color: #082D0E;
}

/* Estilos para la imagen del producto */
.producto img {
    width: 100px; /* Define el ancho de la imagen del producto */
}

/* Estilos para el texto del producto */
.producto p {
    margin-top: 5px; /* Añade espacio superior al texto */
    font-size: 14px; /* Define el tamaño de fuente del texto */
}

</style>

<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\66762\Desktop\MyBlog\resources\views/playeras.blade.php ENDPATH**/ ?>