<!DOCTYPE html>
<html>
<head>
    <title>Detalles del Producto</title>
</head>
<body>
    <h1>Detalles del Producto</h1>
    <p>Nombre: <?php echo e($product->name); ?></p>
    <p>Descripción: <?php echo e($product->description); ?></p>
    <!-- Agrega aquí más detalles del producto -->
</body>
</html>
<?php /**PATH C:\Users\66762\Desktop\MyBlog\resources\views/show.blade.php ENDPATH**/ ?>