<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Mi Aplicación'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <header>
        <nav>
            <ul>
            <li><a href="<?php echo e(url('/files')); ?>">Lista de archivos</a></li>

                <!-- <li><a href="<?php echo e(url('/')); ?>">Inicio</a></li> -->
                <!-- <li><a href="<?php echo e(url('/buscar')); ?>">Buscar</a></li> -->
                <li><a href="<?php echo e(url('/csv')); ?>">Importar</a></li>
                <!-- <li><a href="<?php echo e(url('/generar')); ?>">Generar .csv</a></li> -->
                <li><a href="<?php echo e(url('/upload')); ?>">Juntar archivos</a></li>

            </ul>
        </nav>
    </header>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer>
        <p>© 2024 Mi Aplicación</p>
    </footer>
</body>
</html>
<?php /**PATH C:\Users\66762\Desktop\SANE2.1\resources\views/layouts/app.blade.php ENDPATH**/ ?>