

<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Buscar por CURP</title>
</head>
<body>
    

    <?php if(isset($user)): ?>
        <h1>Datos del usuario: </h1>
         <h2><strong>CURP:</strong> <?php echo e($user->curp); ?> <br>
         <strong>NOMBRE: </strong> <?php echo e($user->nombres); ?> <?php echo e($user->primer_apellido); ?> <?php echo e($user->segundo_apellido); ?> </h2>
        <ul>
            <li><strong> NOMBRE:</strong> <?php echo e($user->nombres); ?></li>
            <li><strong>PRIMER APELLIDO:</strong> <?php echo e($user->primer_apellido); ?></li>
            <li><strong>SEGUNDO APELLIDO: </strong><?php echo e($user->segundo_apellido); ?></li>
            <li><strong>CURP: </strong><?php echo e($user->curp); ?></li>
            <li><strong>FOLIO: </strong><?php echo e($user->folio); ?></li>
            <li><strong>EF: </strong><?php echo e($user->ef); ?></li>
            <li><strong>CVE_ENTIDAD: </strong><?php echo e($user->cve_entidad); ?></li>
            <li><strong>QNA_INICIO: </strong><?php echo e($user->qna_inicio); ?></li>
            <li><strong>CVE_PLAZA_INICIO: </strong><?php echo e($user->cve_plaza_inicio); ?></li>
            <li><strong>TIPO_PLAZA: </strong><?php echo e($user->tipo_plaza); ?></li>
            <li><strong>NUM HORAS: </strong><?php echo e($user->num_horas); ?></li>
            <li><strong>ASIGNATURA: </strong><?php echo e($user->asignatura); ?></li>
            <li><strong>NIVEL_SERVICIO: </strong><?php echo e($user->nivel_servicio); ?></li>
            <li><strong>TIPO_VALORACION: </strong><?php echo e($user->tipo_valoracion); ?></li>
            <li><strong>TIPO_EXAMEN: </strong><?php echo e($user->tipo_examen); ?></li>
            <li><strong>PUNTUACION_GLOBAL: </strong><?php echo e($user->puntuacion_global); ?></li>
            <li><strong>POSICION_ORDENAMIENTO: </strong><?php echo e($user->posicion_ordenamiento); ?></li>
            <li><strong>INCENTIVO_ATP: </strong><?php echo e($user->incentivo_ATP); ?></li>
            <li><strong>INCENTIVO_PFI: </strong><?php echo e($user->incentivo_PFI); ?></li>
            <li><strong>INCENTIVO_CM: </strong><?php echo e($user->incentivo_CM); ?></li>
            <li><strong>INCENTIVO_PH: </strong><?php echo e($user->incentivo_PH); ?></li>
            <li><strong>FUNCION: </strong><?php echo e($user->funcion); ?></li>
            <li><strong>TIPO_ASIGNACION: </strong><?php echo e($user->tipo_asignacion); ?></li>
            <li><strong>CVE_PLAZA_PROMO: </strong><?php echo e($user->cve_plaza_promo); ?></li>
            <li><strong>CVE_CATEGORIA: </strong><?php echo e($user->cve_categoria); ?></li>
            <li><strong>CCT_PROMOCION: </strong><?php echo e($user->cct_promocion); ?></li>
            <li><strong>QNA_TERMINO: </strong><?php echo e($user->qna_termino); ?></li>
            <li><strong>CADUCIDAD_PROMOCION: </strong><?php echo e($user->caducidad_promocion); ?></li>
            <li><strong>CODIGO_NOMBRAMIENTO: </strong><?php echo e($user->codigo_nombramiento); ?></li>
            <li><strong>PROMOCION: </strong><?php echo e($user->promocion); ?></li>
            <li><strong>MOTIVO_BAJA: </strong><?php echo e($user->motivo_baja); ?></li>
            <li><strong>OBSERVACIONES: </strong><?php echo e($user->observaciones); ?></li>
            


            <form action="<?php echo e(route('exportar')); ?>" method="POST">
                
            <?php echo csrf_field(); ?>
            <input type="hidden" name="curp" value="<?php echo e($user->curp); ?>">
            <input type="hidden" name="name" value="<?php echo e($user->nombres); ?>">
            <input type="hidden" name="primer_apellido" value="<?php echo e($user->primer_apellido); ?>">
            <input type="hidden" name="segundo_apellido" value="<?php echo e($user->segundo_apellido); ?>">
            <input type="hidden" name="folio" value="<?php echo e($user->folio); ?>">
            <input type="hidden" name="ef" value="<?php echo e($user->ef); ?>">
            <input type="hidden" name="cve_entidad" value="<?php echo e($user->cve_entidad); ?>">
            <input type="hidden" name="qna_inicio" value="<?php echo e($user->qna_inicio); ?>">
            <input type="hidden" name="cve_plaza_inicio" value="<?php echo e($user->cve_plaza_inicio); ?>">
            <input type="hidden" name="tipo_plaza" value="<?php echo e($user->tipo_plaza); ?>">
            <input type="hidden" name="num_horas" value="<?php echo e($user->num_horas); ?>">
            <input type="hidden" name="asignatura" value="<?php echo e($user->asignatura); ?>">
            <input type="hidden" name="nivel_servicio" value="<?php echo e($user->nivel_servicio); ?>">
            <input type="hidden" name="tipo_valoracion" value="<?php echo e($user->tipo_valoracion); ?>">
            <input type="hidden" name="tipo_examen" value="<?php echo e($user->tipo_examen); ?>">
            <input type="hidden" name="puntuacion_global" value="<?php echo e($user->puntuacion_global); ?>">
            <input type="hidden" name="posicion_ordenamiento" value="<?php echo e($user->posicion_ordenamiento); ?>">
            <input type="hidden" name="incentivo_atp" value="<?php echo e($user->incentivo_ATP); ?>">
            <input type="hidden" name="incentivo_pfi" value="<?php echo e($user->incentivo_PFI); ?>">
            <input type="hidden" name="incentivo_cm" value="<?php echo e($user->incentivo_CM); ?>">
            <input type="hidden" name="incentivo_ph" value="<?php echo e($user->incentivo_PH); ?>">
            <input type="hidden" name="funcion" value="<?php echo e($user->funcion); ?>">
            <input type="hidden" name="tipo_asignacion" value="<?php echo e($user->tipo_asignacion); ?>">
            <input type="hidden" name="cve_plaza_promo" value="<?php echo e($user->cve_plaza_promo); ?>">
            <input type="hidden" name="cve_categoria" value="<?php echo e($user->cve_categoria); ?>">
            <input type="hidden" name="cct_promocion" value="<?php echo e($user->cct_promocion); ?>">
            <input type="hidden" name="qna_termino" value="<?php echo e($user->qna_termino); ?>">
            <input type="hidden" name="caducidad_promocion" value="<?php echo e($user->caducidad_promocion); ?>">
            <input type="hidden" name="codigo_nombramiento" value="<?php echo e($user->codigo_nombramiento); ?>">
            <input type="hidden" name="promocion" value="<?php echo e($user->promocion); ?>">
            <input type="hidden" name="motivo_baja" value="<?php echo e($user->motivo_baja); ?>">
            <input type="hidden" name="observaciones" value="<?php echo e($user->observaciones); ?>">
            
            <button type="submit" class="btn success animated-button"><span>Descargar Información del Usuario</span></button>
        </form>
            
        </ul>
        
    <?php elseif(isset($error)): ?>
        <p><?php echo e($error); ?></p>
    <?php endif; ?>

    
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\66762\Desktop\SANE2.5\resources\views/search.blade.php ENDPATH**/ ?>