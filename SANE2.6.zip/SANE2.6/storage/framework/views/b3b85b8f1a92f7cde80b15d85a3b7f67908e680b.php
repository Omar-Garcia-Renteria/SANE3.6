

<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Buscar por CURP</title>
</head>
<body>
    

    <?php if(isset($user)): ?>
        <h2>Datos básicos del usuario:</h2>
        <ul>
            <li>ID: <?php echo e($user->id_ent); ?></li>
            <li>NOMBRE: <?php echo e($user->name); ?></li>
            <li>PRIMER APELLIDO: <?php echo e($user->prim_apell); ?></li>
            <li>SEGUNDO APELLIDO: <?php echo e($user->seg_apell); ?></li>
            <li>CURP: <?php echo e($user->curp); ?></li>
            <li>CORREO: <?php echo e($user->email); ?></li>
            <li>NUMERO DE TELEFONO: <?php echo e($user->numero); ?></li>
            <li>EF: <?php echo e($user->ef); ?></li>


            <form action="<?php echo e(route('exportar')); ?>" method="POST">
                
            <?php echo csrf_field(); ?>
            <input type="hidden" name="curp" value="<?php echo e($user->curp); ?>">
            <input type="hidden" name="name" value="<?php echo e($user->name); ?>">
            <input type="hidden" name="prim_apell" value="<?php echo e($user->prim_apell); ?>">
            <input type="hidden" name="email" value="<?php echo e($user->email); ?>">
            <input type="hidden" name="id_ent" value="<?php echo e($user->id_ent); ?>">
            <input type="hidden" name="id_ent" value="<?php echo e($user->numero); ?>">
            <button type="submit">Exportar a CSV</button>
        </form>
            
        </ul>
        
    <?php elseif(isset($error)): ?>
        <p><?php echo e($error); ?></p>
    <?php endif; ?>

    
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\66762\Desktop\SANE1.0\resources\views/search.blade.php ENDPATH**/ ?>