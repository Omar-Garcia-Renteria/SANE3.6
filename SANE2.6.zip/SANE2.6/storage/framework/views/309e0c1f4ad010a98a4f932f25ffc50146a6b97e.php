

<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Curps</title>
</head>
<body>
    <h1>Datos del Archivo</h1>
    <table border="1">
        <thead>
            <!-- <tr>
                <th>CURP</th>
                <th>Folio</th>
                <th>Nombres</th>
                <th>Primer Apellido</th>
                <th>Segundo Apellido</th>
                <th>CVE Entidad</th>
                <th>QNA Inicio</th>
                <th>CVE Plaza Inicio</th>
                <th>Tipo Plaza</th>
                <th>Num Horas</th>
                <th>Asignatura</th>
                <th>Nivel Servicio</th>
                <th>Tipo Valoración</th>
                <th>Tipo Examen</th>
                <th>Puntuación Global</th>
                <th>Posición Ordenamiento</th>
                <th>Incentivo ATP</th>
                <th>Incentivo PFI</th>
                <th>Incentivo CM</th>
                <th>Incentivo PH</th>
                <th>Función</th>
                <th>Tipo Asignación</th>
                <th>CVE Plaza Promo</th>
                <th>CVE Categoría</th>
                <th>CCT Promoción</th>
                <th>QNA Término</th>
                <th>Caducidad Promoción</th>
                <th>Código Nombramiento</th>
                <th>Promoción</th>
                <th>Motivo Baja</th>
                <th>Observaciones</th>
            </tr> -->
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

                <td><?php echo e($user->operacion); ?></td>
                <td><?php echo e($user->ciclo); ?></td>
                <td><?php echo e($user->curp); ?></td>
                <td><?php echo e($user->cve_plaza_inicio); ?></td>
                <td><?php echo e($user->tipo_plaza); ?></td>
                <td><?php echo e($user->num_horas); ?></td>
                <td><?php echo e($user->asignatura); ?></td>
                <td><?php echo e($user->nivel_servicio); ?></td>
                <td><?php echo e($user->tipo_valoracion); ?></td>
                <td><?php echo e($user->tipo_examen); ?></td>
                <td><?php echo e($user->puntuacion_global); ?></td>
                <td><?php echo e($user->posicion_ordenamiento); ?></td>
                <td><?php echo e($user->incentivo_atp); ?></td>
                <td><?php echo e($user->incentivo_pfi); ?></td>
                <td><?php echo e($user->incentivo_cm); ?></td>
                <td><?php echo e($user->incentivo_ph); ?></td>
                <td><?php echo e($user->nombres); ?></td>
                <td><?php echo e($user->primer_apellido); ?></td>
                <td><?php echo e($user->segundo_apellido); ?></td>
                <td><?php echo e($user->funcion); ?></td>
                <td><?php echo e($user->tipo_asignacion); ?></td>
                <td><?php echo e($user->cve_plaza_promocion); ?></td>
                <td><?php echo e($user->cve_categoria); ?></td>
                <td><?php echo e($user->cct_promocion); ?></td>
                <td><?php echo e($user->qna_inicio); ?></td>
                <td><?php echo e($user->qna_termino); ?></td>
                <td><?php echo e($user->caducidad_promocion); ?></td>
                <td><?php echo e($user->codigo_nombramiento); ?></td>
                <td><?php echo e($user->promocion); ?></td>
                <td><?php echo e($user->motivo_baja); ?></td>
                <td><?php echo e($user->cve_entidad); ?></td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\66762\Desktop\SANE2.3\resources\views/curps.blade.php ENDPATH**/ ?>