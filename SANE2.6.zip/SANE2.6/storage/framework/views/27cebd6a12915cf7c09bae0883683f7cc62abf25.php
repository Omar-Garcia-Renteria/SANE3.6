

<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" type="text/css"> -->
    <title>Importar</title>
</head>
<body>
    <header>
    <nav class="header2">
        Importar archivo (CSV)
    </nav>
    </header>

    <h1 style="text-align:center;">Importar Archivo</h1>
    <table border="1" style="margin: 0 auto;">
<tr>
    <td>
    <div class="form-container">
    <form action="<?php echo e(route('importar2.post')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="document_csv"> <br> <br>

    <button type="submit" class="btn success animated-button" redirect="list_files" required><span>Importar</span></button>
</form>
</div>
</td></tr>

</table>

    
</body>
</html>
<?php $__env->stopSection(); ?>

<style>
    table {
   border-collapse: separate;
   border-spacing: 5px;
   background: rgba(73,97,91,255) bottom left repeat-x;
   color: #fff;
}
td, th {
   background: #fff;
   color: #000;
}

.form-container {
    padding: 20px; /* Agrega espacio entre el borde de la tabla y el formulario */
    text-align: center; /* Centra el formulario y los botones */
  }
</style>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SANE\SANE2.6\resources\views/csv.blade.php ENDPATH**/ ?>