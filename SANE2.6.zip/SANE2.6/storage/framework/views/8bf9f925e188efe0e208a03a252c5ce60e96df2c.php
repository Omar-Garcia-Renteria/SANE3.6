

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Datos del Archivo</h1>
    <div class="scrollable">
    <ul>
    <table class="table table-bordered" border="1">
        <thead>
            <tr>
                <th>OPERACION</th>
                <th>CICLO ESCOLAR</th>
                <th>EF</th>
                <th>CURP</th>     
                <th>CLAVE PALZA INICIO</th>
                <th>TIPO PLAZA</th>
                <th>NUMERO HORAS</th>
                <th>ASIGNATURA</th>
                <th>NIVEL SERVICIO</th>
                <th>TIPO VALORACION</th>
                <th>TIPO EXAMEN</th>
                <th>PUNTUACION GLOBAL</th>
                <th>POSICION ORDENAMIENTO</th>
                <th>INCENTIVO ATP</th>
                <th>INCENTIVO PFI</th>
                <th>INCENTIVO CM</th>
                <th>INCENTIVO PH</th>
                <th>NOMBRE(S)</th>
                <th>PRIMER APELLIDO</th>
                <th>SEGUNDO APELLIDO</th>
                <th>FUNCION</th>
                <th>TIPO ASIGNACION</th>
                <th>CVE PLAZA PROMOCION</th>
                <th>CVE CATEGORIA</th>
                <th>CCT PROMOCION</th>
                <th>QNA INICIO</th>
                <th>QNA TERMINO</th>
                <th>CADUCIDAD PROMOCION</th>
                <th>CODIGO NOMBRAMIENTO</th>
                <th>PROMOCION</th>
                <th>OBSERVACIONES</th>
                <th>FECHA ALTA</th>
                <th>MOTIVO BAJA</th>
                <th>CLAVE ENTIDAD</th>
            </tr>
        </thead>
        <form action="<?php echo e(route('exportar')); ?>" method="POST">

        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->operacion); ?></td>
                <td><?php echo e($user->ciclo_escolar); ?></td>
                <td><?php echo e($user->ef); ?></td>
                <td><?php echo e($user->curp); ?></td>
                <td><?php echo e($user->cve_plaza_inicio); ?></td>
                <td><?php echo e($user->tipo_plaza); ?></td>
                <td><?php echo e($user->num_horas); ?></td>
                <td><?php echo e($user->asignatura); ?></td>
                <td><?php echo e($user->nivel_servicio); ?></td>
                <td><?php echo e($user->tipo_valoracion); ?></td>
                <td><?php echo e($user->tipo_examen); ?></td>
                <td><?php echo e($user->puntuacion_global); ?></td>
                <td><?php echo e($user->posicion_ordenamiento); ?></td>
                <td><?php echo e($user->incentivo_ATP); ?></td>
                <td><?php echo e($user->incentivo_PFI); ?></td>
                <td><?php echo e($user->incentivo_CM); ?></td>
                <td><?php echo e($user->incentivo_PH); ?></td>
                <td><?php echo e($user->nombres); ?></td>
                <td><?php echo e($user->primer_apellido); ?></td>
                <td><?php echo e($user->segundo_apellido); ?></td>
                <td><?php echo e($user->funcion); ?></td>
                <td><?php echo e($user->tipo_asignacion); ?></td>
                <td><?php echo e($user->cve_plaza_promo); ?></td>
                <td><?php echo e($user->cve_categoria); ?></td>
                <td><?php echo e($user->cct_promocion); ?></td>
                <td><?php echo e($user->qna_inicio); ?></td>
                <td><?php echo e($user->qna_termino); ?></td>
                <td><?php echo e($user->caducidad_promocion); ?></td>
                <td><?php echo e($user->codigo_nombramiento); ?></td>
                <td><?php echo e($user->promocion); ?></td>
                <td><?php echo e($user->observaciones); ?></td>
                <td><?php echo e($user->fecha_alta); ?></td>
                <td><?php echo e($user->motivo_baja); ?></td>
                <td><?php echo e($user->cve_entidad); ?></td>
            </tr>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<style>
    table {
   border-collapse: separate;
   border-spacing: 5px;
   background: rgba(73,97,91,255) bottom left repeat-x;
   color: #fff;
}
td, th {
   background: #fff;
   color: #000;
}

.scrollable {
            overflow-x: auto;
            white-space: nowrap;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
</style>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\66762\Desktop\SANE2.6\resources\views/curps.blade.php ENDPATH**/ ?>