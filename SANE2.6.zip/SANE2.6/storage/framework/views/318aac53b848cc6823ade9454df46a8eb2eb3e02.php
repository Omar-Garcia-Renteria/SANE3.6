<!DOCTYPE html>
<html>
<head>
    <title>User Data</title>
</head>
<body>
    <h1>Datos de los usuarios</h1>
    <table>
        <thead>
            <!-- <tr>
                <th>ID</th>
                <th>Name</th>
                <th>CURP</th>
                <th>Email</th>
            </tr> -->
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->id_ent); ?></td>
                <td><?php echo e($user->nombre); ?></td>
                <td><?php echo e($user->prim_apell); ?></td>
                <td><?php echo e($user->seg_apell); ?></td>
                <td><?php echo e($user->curp); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->numero); ?></td>
                <td><?php echo e($user->promocion); ?></td>
                <td><?php echo e($user->observaciones); ?></td>
                <td><?php echo e($user->ciclo_escolar); ?></td>
                <td><?php echo e($user->ef); ?></td>
                <td><?php echo e($user->tipo_valoracion); ?></td>
                <td><?php echo e($user->cve_plaza_inicio); ?></td>
                <td><?php echo e($user->cve_plaza_promocion); ?></td>
                <td><?php echo e($user->tipo_plaza); ?></td>
                <td><?php echo e($user->num_horas); ?></td>
                <td><?php echo e($user->asignatura); ?></td>
                <td><?php echo e($user->nivel_servicio); ?></td>
                <td><?php echo e($user->tipo_examen); ?></td>
                <td><?php echo e($user->puntuacion_global); ?></td>
                <td><?php echo e($user->posicion_ordenamiento); ?></td>
                <td><?php echo e($user->incentivo_atp); ?></td>
                <td><?php echo e($user->incentivo_pfi); ?></td>
                <td><?php echo e($user->incentivo_cm); ?></td>
                <td><?php echo e($user->incentivo_ph); ?></td>
                <td><?php echo e($user->funcion); ?></td>
                <td><?php echo e($user->tipo_asignacion); ?></td>
                <td><?php echo e($user->cve_categoria); ?></td>
                <td><?php echo e($user->cct_promocion); ?></td>
                <td><?php echo e($user->qna_inicio); ?></td>
                <td><?php echo e($user->qna_termino); ?></td>
                <td><?php echo e($user->caducidad_promocion); ?></td>
                <td><?php echo e($user->codigo_nombramiento); ?></td>
                <td><?php echo e($user->tabla33); ?></td>
                <td><?php echo e($user->tabla34); ?></td>
                <td><?php echo e($user->tabla35); ?></td>
                <td><?php echo e($user->tabla36); ?></td>
                <td><?php echo e($user->tabla38); ?></td>
                <td><?php echo e($user->tabla40); ?></td>
                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="container">
        <br>
        <div class="row">
            <div class="clod-md-4"></div>
            <div class="clod-md-6">
            <!-- <div class="row">

                <form method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                <div class="clo-md-6">
                    <input type="file" name="documento">
                </div>
                <div class="clo-md-6">
                    <button class="btn btn-primary" type="submit">Importar</button>
                </div>
                </form>
            </div> -->
            </div>
            <!-- <head>
    <title>Buscar por CURP</title>
</head>
<body>
    <form action="<?php echo e(route('search')); ?>" method="GET">
        <label for="curp">CURP:</label>
        <input type="text" id="curp" name="curp" required>
        <button type="submit">Buscar</button>
        <div class="col-md-2">
                <button class="btn btn-success">Exportar</button>
            </div>
    </form>

    


</body> -->

<style>
        td {
            font-weight: bold; 
            font-size: 20px; 
        }
    </style>


</html>
<?php /**PATH C:\Users\66762\Desktop\SANE1.0\resources\views/curps.blade.php ENDPATH**/ ?>