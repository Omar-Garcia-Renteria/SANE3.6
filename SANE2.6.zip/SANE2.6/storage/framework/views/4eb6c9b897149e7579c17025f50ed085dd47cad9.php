
<!DOCTYPE html>




<?php $__env->startSection('contenido'); ?>
    <div class="container">
        <p>NIKE</p>
    </div>

    <div class="productos">
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/ace5a056-1c85-44e5-a15c-a506a60183eb/calzado-de-skateboarding-sb-force-58-NhH3tS.png" alt="" width="80px">
        <p><a href="/zap">Nike SB Force 58</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/f287c46f-8e12-4978-a047-1c51f85a2a85/calzado-shox-tl-S0jvjJ.png" alt="" width="80px">
        <p><a href="/zap">Nike Shox TL</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/76ca9ffe-604f-4848-af6e-53b8e09efb31/calzado-de-running-en-carretera-flex-experience-run-12-K2D4PX.png" alt="" width="80px">
        <p><a href="/zap">Nike Flex Experience Run 12</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/e039906f-d10e-49d2-a729-d2d55f0ebc97/calzado-de-skateboarding-sb-zoom-blazer-low-pro-gt-bMwZmc.png" alt="" width="80px">
        <p><a href="/zap">Nike SB Zoom Blazer Low Pro GT</a></p>
    </div>
</div>

<div class="productos">
    <div class="producto"style="display: inline-block; text-align: center;">
        <img src="https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/be7b2bf6-7d42-41d7-ac6c-7fb08b81479d/calzado-de-tenis-de-cancha-dura-court-zoom-vapor-cage-4-rafa-1t7FzV.png" alt="" width="80px">
        <p><a href="/zap">NikeCourt Zoom Vapor Cage 4 Rafa</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/2774afcc-bb23-4e30-9744-af7d9fed9e62/calzado-de-tenis-de-cancha-dura-court-air-zoom-vapor-pro-2-premium-rhrChs.png" alt="" width="80px">
        <p><a href="/zap">NikeCourt Air Zoom Vapor Pro 2 Premium</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/1ae733b3-daac-4a07-a299-8ebbda852b82/calzado-de-trail-running-wildhorse-8-qwnP9v.png" alt="" width="80px">
        <p><a href="/zap">Nike Wildhorse 8</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/30d7afaa-343b-4439-b65d-bb544c65420e/calzado-de-running-en-carretera-revolution-7-tr13gr.png" alt="" width="80px">
        <p><a href="/zap">Nike Revolution 7</a></p>
    </div>
</div>



<style>
    /* Estilos para el contenedor de productos */
.productos {
    text-align: center; /* Centra los productos horizontalmente */
    color: #082D0E;
}

/* Estilos para cada contenedor de producto */
.producto {
    display: inline-block; /* Muestra los productos en línea */
    margin: 10px; /* Añade un margen alrededor de cada producto */
    padding: 10px; /* Añade espacio interno alrededor de cada producto */
    border: 1px solid #ccc; /* Agrega un borde alrededor de cada producto */
    width: 150px; /* Define el ancho de cada producto */
    color: #082D0E;
}

/* Estilos para la imagen del producto */
.producto img {
    width: 100px; /* Define el ancho de la imagen del producto */
}

/* Estilos para el texto del producto */
.producto p {
    margin-top: 5px; /* Añade espacio superior al texto */
    font-size: 14px; /* Define el tamaño de fuente del texto */
}

</style>

<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\66762\Desktop\CRUZ\MyBlog2\resources\views/nike.blade.php ENDPATH**/ ?>