<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Mi Aplicación'); ?></title>
    <link href="<?php echo e(asset('css/buttons.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <style>
        nav ul {
            list-style-type: none; /* Quitar viñetas de la lista */
            padding: 0;
        }

        nav ul li {
            display: inline-block; /* Mostrar los <li> como bloques en línea */
            margin-right: 10px; /* Espacio entre los botones */
        }

        nav ul li a {
            text-decoration: none;
            padding: 10px 20px;
            background-color: rgb(127, 169, 194); /* Color de fondo del botón */
            color: white; /* Color del texto */
            border-radius: 5px; /* Bordes redondeados */
            transition: background-color 0.3s ease; /* Animación suave al pasar el mouse */
        }

        nav ul li a:hover {
            background-color: #0056b3; /* Color de fondo al pasar el mouse */
        }

        .button {
            margin: 0 auto;
            top: 10%;
            left: 10%;
        }
    </style>
</head>
<body>
    <header class="header1">
        <nav>
            <ul>
                <li><a href="javascript:history.back()">Volver Atrás</a></li>
                <li><a href="<?php echo e(url('/upload')); ?>">Juntar archivos</a></li>
                <li><a href="<?php echo e(url('/csv')); ?>">Importar</a></li>
                <li><a href="<?php echo e(url('/files')); ?>">Lista de archivos</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer>
        <img src="<?php echo e(asset('images/sep.png')); ?>" alt="Secretaria De Educacion Estado De Zacatecas" style="display: block; margin: 0 auto; width: 200px; height: auto;">
        <p>© <?php echo e(date('Y')); ?>-<?php echo e(date('Y') + 1); ?> SEP</p>
    </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\SANE\SANE2.6\resources\views/layouts/app.blade.php ENDPATH**/ ?>