
<!DOCTYPE html>




<?php $__env->startSection('contenido'); ?>
    <div class="container">
        
    </div>



<div>
    
    <a href="/nike">NIKE <br>
    <img src="https://i.pinimg.com/736x/c6/30/47/c630470cb3ec52076a4fefda1c232d6f.jpg" alt="" width="300px"></a>
    <br> <br>

    <a href="/adidas">ADIDAS <br>
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSXxoxiN1s1P8LIjpQo5UgrOl5DWTJcF-fjAOEIPWyUQA&s" alt="" width="300px"></a>
    <br> <br>

    <a href="/puma">PUMA</a> <br>
    <img src="https://w7.pngwing.com/pngs/100/126/png-transparent-puma-logo-thumbnail.png" alt="" width="300px"></a>
    <br> <br>

    <a href="/playeras">PLAYERAS <br>
    <img src="https://e00-marca.uecdn.es/assets/multimedia/imagenes/2019/09/11/15682322418204.jpg" alt="" width="300px"></a>
    <br> <br>
    

</div>
    
<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\66762\Desktop\MyBlog\resources\views/home.blade.php ENDPATH**/ ?>