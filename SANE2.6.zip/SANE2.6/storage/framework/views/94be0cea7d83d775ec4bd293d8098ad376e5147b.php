

<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Subir Archivos</title>
</head>
<body>

    <header>
    <nav>
Generar archivo SANE    
    </nav>
    </header>

    <h1>Combinar archivos Excel (Xlsx)</h1>
    <form action="<?php echo e(route('upload')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="file1" >Listas:</label>
        <input type="file" name="file1" required ><br>

        <label for="file2" >Reporte:</label>
        <input type="file" name="file2" required ><br>

        <label for="filename">Nombre del Archivo:</label>
        <input type="text" name="filename" required><br>

        <button type="submit" class="btn success animated-button"> <span> Combinar y Descargar</span></button>

        
    </form>
    
</body>
</html>
<?php $__env->stopSection(); ?>

<style>


</style>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\66762\Desktop\SANE2.4\resources\views//upload.blade.php ENDPATH**/ ?>