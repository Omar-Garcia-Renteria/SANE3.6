

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Archivos Importados</title>
</head>
<body>
<header>
    <nav>
          Lista de archivos importados
    </nav>
    </header>

    <h1>Archivos Importados</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Nombre del Archivo</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($file->file_name); ?></td>
                    <td>
                    
                        <form action="<?php echo e(route('files.show', $file->id)); ?>" method="GET" style="display:inline;">
                            <button type="submit" class="btn success animated-button"><span>Ver</span></button>
                        </form>

                        <form action="<?php echo e(route('files.search', $file->id)); ?>" method="GET" style="display:inline;">
                            <input type="text" name="curp" placeholder="Buscar por CURP" class="btn secondary">
                            <button type="submit" class="btn primary animated-button" required><span>Buscar</span></button>
                        </form>

                        <form action="<?php echo e(route('files.destroy', $file->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" onclick="return confirm('¿Estás seguro de que deseas eliminar este archivo?');" class="btn danger animated-button"><span>Eliminar</span></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <a href="/csv">Importar archivo (.csv)</a>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\66762\Desktop\SANE2.4\resources\views/list_files.blade.php ENDPATH**/ ?>