

<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Importar</title>
</head>
<body>
    <header>
        <nav>
            <!-- Aquí puedes añadir la navegación si es necesario -->
        </nav>
    </header>
    <h1>Importar Archivos CSV</h1>
    <form action="<?php echo e(route('importar.post')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div>
            <label for="document_csv1">Archivo CSV 1:</label>
            <input type="file" name="document_csv1" id="document_csv1" required>
        </div>
        <div>
            <label for="document_csv2">Archivo CSV 2:</label>
            <input type="file" name="document_csv2" id="document_csv2" required>
        </div>
        <button type="submit">Importar CSV</button>
    </form>

    <a href="/files">Ver Archivos</a>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\66762\Desktop\SANE2.0\resources\views/csv.blade.php ENDPATH**/ ?>