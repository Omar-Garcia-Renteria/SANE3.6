<!DOCTYPE html>




<?php $__env->startSection('contenido'); ?>

<h1>INFORMACION DEL PRODUCTO</h1>

<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\66762\Desktop\MyBlog\resources\views/zap.blade.php ENDPATH**/ ?>