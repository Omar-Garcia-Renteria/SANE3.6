<!DOCTYPE html>
<html>
<head>
    <title>Subir Archivos</title>
</head>
<body>
    <h1>Subir y combinar archivos Excel</h1>
    <form action="<?php echo e(route('upload')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="file1">Archivo 1:</label>
        <input type="file" name="file1" required><br>

        <label for="file2">Archivo 2:</label>
        <input type="file" name="file2" required><br>

        <label for="filename">Nombre del archivo:</label>
        <input type="text" name="filename" required><br>

        <button type="submit">Subir y combinar</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\66762\Desktop\SANE2.0\resources\views/upload.blade.php ENDPATH**/ ?>