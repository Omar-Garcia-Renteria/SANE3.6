


<!DOCTYPE html>




<?php $__env->startSection('contenido'); ?>
    <div class="container">
        <p>ADIDAS</p>
    </div>

    <div class="productos">
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/e4a1154466e347f7a00856f0c7327afc_9366/Tenis_Superstar_Negro_IH3121_01_standard.jpg" alt="" width="80px">
        <p><a href="/zap">TENIS SUPERSTAR</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/547a771694804302a525f76282bbce9f_9366/Tenis_Jamaica_OG_Gris_IH3241_01_standard.jpg" alt="" width="80px">
        <p><a href="/zap">TENIS JAMAICA OG</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/11c53f450a33468ea4de3a06a38611ae_9366/Tenis_Orketro_2_Azul_IF0375_01_standard.jpg" alt="" width="80px">
        <p><a href="/zap">TENIS ORKETRO 2</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/5086ddb793e34ff8b2edafcd01122b72_9366/Tenis_Midcity_Low_Negro_IE4518_01_standard.jpg" alt="" width="80px">
        <p><a href="/zap">TENIS MIDCITY LOW</a></p>
    </div>
</div>

<div class="productos">
    <div class="producto"style="display: inline-block; text-align: center;">
        <img src="https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/8ee2703e7adb4545bbfcadcb0116ec66_9366/Tenis_Postmove_Mid_Blanco_GZ1338_01_standard.jpg" alt="" width="80px">
        <p><a href="/zap">TENIS POSTMOVE MID</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/47ea5ab212db40b0802eae8101697d68_9366/Tenis_Hoops_3.0_Low_Classic_Vintage_Negro_GY4727_01_standard.jpg" alt="" width="80px">
        <p><a href="/zap">TENIS HOOPS 3.0 LOW CLASSIC VINTAGE</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/dc9953df47e443a79524adc50177d71e_9366/Tenis_Hoops_3.0_Low_Classic_Vintage_Blanco_GY5427_01_standard.jpg" alt="" width="80px">
        <p><a href="/zap">TENIS HOOPS 3.0 LOW CLASSIC VINTAGE</a></p>
    </div>
    <div class="producto" style="display: inline-block; text-align: center;">
        <img src="https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/823332d71746459fb82baf56015bb0b9_9366/Tenis_Top_Ten_2010_Blanco_HR0099_01_standard.jpg" alt="" width="80px">
        <p><a href="/zap">TENIS TOP TEN 2010</a></p>
    </div>
</div>



<style>
    /* Estilos para el contenedor de productos */
.productos {
    text-align: center; /* Centra los productos horizontalmente */
    color: #082D0E;
}

/* Estilos para cada contenedor de producto */
.producto {
    display: inline-block; /* Muestra los productos en línea */
    margin: 10px; /* Añade un margen alrededor de cada producto */
    padding: 10px; /* Añade espacio interno alrededor de cada producto */
    border: 1px solid #ccc; /* Agrega un borde alrededor de cada producto */
    width: 150px; /* Define el ancho de cada producto */
    color: #082D0E;
}

/* Estilos para la imagen del producto */
.producto img {
    width: 100px; /* Define el ancho de la imagen del producto */
}

/* Estilos para el texto del producto */
.producto p {
    margin-top: 5px; /* Añade espacio superior al texto */
    font-size: 14px; /* Define el tamaño de fuente del texto */
}

</style>

<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\66762\Desktop\MyBlog\resources\views/adidas.blade.php ENDPATH**/ ?>